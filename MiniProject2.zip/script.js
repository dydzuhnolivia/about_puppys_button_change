var button = $ ('button');

//event listener
button.on('click',changeColors);
var puppy = $('img');
//event handler
function changeColors()
{
  button.toggleClass('orange');
  
}

puppy.css("border","4px dashed grey")